test("prueba simple", () => {
  expect(1 + 1).toBe(2);
});
